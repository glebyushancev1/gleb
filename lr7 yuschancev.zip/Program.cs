﻿using System.Collections.Generic;
using System.Linq;
using System;

Console.WriteLine("Задание 2");
string[] allList = {"Ermolaev","Kadyshev","Dikarev","Gavrilenko","Hromov",
                "Kalinin","Goryachev", "Devyatkin","Shyaev","Kochnov"};
string[] list1 = { "Ermolaev", "Kadyshev", "Dikarev", "Gavrilenko" };
string[] list2 = { "Hromov", "Kalinin", "Dikarev", "Goryachev" };
string[] list3 = { "Kadyshev", "Devyatkin", "Shyaev", "Dikarev" };
string[] list4 = { "Kadyshev", "Shyaev", "Hromov", "Dikarev" };
string[] list5 = { "Dikarev", "Ermolaev" };
PrintSet(allList);
PrintSet(list1);
PrintSet(list2);
PrintSet(list3);
PrintSet(list4);
PrintSet(list5);
Console.WriteLine("Входит во все множества:");
PrintSet(list1.Intersect(list2).Intersect(list3).Intersect(list4).Intersect(list5));

Console.WriteLine("НЕ входит ни в одно множества:");
PrintSet(allList.Except(list1).Except(list2).Except(list3).Except(list4).Except(list5));

Console.WriteLine("Входят только в четвертое множество:");
PrintSet(list4);

static void PrintSet(IEnumerable<string> set)
{
    foreach (string c in set)
    {
        Console.Write($"{c} ");
    }
    Console.WriteLine();
}
