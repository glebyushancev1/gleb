﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace yuschancev:
Console.WriteLine("Задание 2");
string[] allList = {"Яблоко","Шоколад","Морковь","Чипсы","Сухарики",
                "Кортофель","Говядина", "Авокадо","Памелло","Печенье"};
string[] list1 = { "Яблоко", "Шоколад", "Авокадо", "Памелло" };
string[] list2 = { "Кортофель", "Говядина", "Авокадо", "Печенье" };
string[] list3 = { "Шоколад", "Морковь", "Чипсы", "Авокадо" };
string[] list4 = { "Шоколад", "Чипсы", "Кортофель", "Авокадо" };
string[] list5 = { "Говядина", "Авокадо" };
PrintSet(allList);
PrintSet(list1);
PrintSet(list2);
PrintSet(list3);
PrintSet(list4);
PrintSet(list5);
Console.WriteLine("Входит во все множества:");
PrintSet(list1.Intersect(list2).Intersect(list3).Intersect(list4).Intersect(list5));
Console.WriteLine("НЕ входит ни в одно множества:");
PrintSet(allList.Except(list1).Except(list2).Except(list3).Except(list4).Except(list5));
Console.WriteLine("Входят только в четвертое множество:");
PrintSet(list4);

static void PrintSet(IEnumerable<string> set)
{
    foreach (string c in set)
    {
        Console.Write($"{c} ");
    }
    Console.WriteLine();
}

   